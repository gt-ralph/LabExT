
									***WARNING***

This Legacy SDK was designed for the Thorlabs Scientific CCD cameras only, and those cameras are no longer being manufactured 

This SDK is not compatible with our current CMOS and sCMOS scientific cameras and is longer actively maintained.

