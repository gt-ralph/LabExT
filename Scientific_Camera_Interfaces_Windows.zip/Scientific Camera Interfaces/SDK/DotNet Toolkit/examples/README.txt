The solution and project files were created using Visual Studio 2019.

The projects target .NET 4, although any more recent version will work equally well.

The polling examples show how to stream images from the camera using a single thread.
The callback examples show how to stream images from the camera using a UI thread for the GUI and a worker thread for the frame-available callbacks.