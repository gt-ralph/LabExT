The polling examples show how to acquire images from the camera using a single thread.

The callback examples show how to acquire images from the camera using a worker thread for the frame-available callbacks.